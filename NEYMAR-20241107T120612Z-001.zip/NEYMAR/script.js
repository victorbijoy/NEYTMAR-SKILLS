document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Sua pergunta foi enviada!');
});
